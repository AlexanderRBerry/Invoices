﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoices.Main
{
    public class clsMainLogic
    {
        //GetAllItems returns List<clsItem>
        //SaveNewInvoice(clsInvoice)
        //EditInvoice(clsOldInvoice, clsNewInvoice)
        //GetInvoice(InvoiceNumber) returns clsInvoice - Get the invoice and items for the selected invoice from search window
    }
}
