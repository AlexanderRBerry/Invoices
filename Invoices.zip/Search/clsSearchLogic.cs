﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exception_Handler;

namespace Invoices.Search
{

    public class clsSearchLogic
    {
        
    }
}
